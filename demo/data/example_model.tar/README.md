Model przykładowy/testowy. Posiada trzy sygnatury:
* "serving_default"
* "pi"
* "e"
